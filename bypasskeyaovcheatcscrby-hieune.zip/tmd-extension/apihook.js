(function () {
  if (window.__tmdApiHooked) return;
  window.__tmdApiHooked = true;

  const RE_URL = /result=([A-Za-z0-9_.\-]*tumadam[A-Za-z0-9_.\-]*)/;
  const RE_TXT = /(tumadam(?:-\w+)+-\w+)/;

  function emit(key, url) {
    try {
      window.dispatchEvent(new CustomEvent('tmd-api-key', { detail: { key: key, url: url || '' } }));
    } catch (e) {}
    try { sessionStorage.setItem('tmd_api_key', key); } catch (e) {}
  }

  function scan(url, text) {
    try {
      if (url) {
        const m = RE_URL.exec(url);
        if (m && m[1]) { emit(m[1], url); return; }
      }
      if (typeof text === 'string' && text.length < 5000000) {
        let m2 = RE_URL.exec(text);
        if (m2 && m2[1]) { emit(m2[1], url); return; }
        m2 = RE_TXT.exec(text);
        if (m2) emit(m2[1], url);
      }
    } catch (e) {}
  }

  const origFetch = window.fetch;
  if (origFetch) {
    window.fetch = function () {
      const arg = arguments[0];
      let url = '';
      try { url = (arg && arg.url) ? arg.url : String(arg); } catch (e) {}
      return origFetch.apply(this, arguments).then(function (res) {
        try {
          scan(res.url || url, '');
          res.clone().text().then(function (t) { scan(res.url || url, t); }).catch(function () {});
        } catch (e) {}
        return res;
      });
    };
  }

  const origOpen = XMLHttpRequest.prototype.open;
  const origSend = XMLHttpRequest.prototype.send;
  XMLHttpRequest.prototype.open = function (method, u) {
    this.__tmdUrl = u;
    return origOpen.apply(this, arguments);
  };
  XMLHttpRequest.prototype.send = function () {
    const xhr = this;
    xhr.addEventListener('load', function () {
      try {
        scan(xhr.responseURL || xhr.__tmdUrl, typeof xhr.responseText === 'string' ? xhr.responseText : '');
      } catch (e) {}
    });
    return origSend.apply(this, arguments);
  };
})();
