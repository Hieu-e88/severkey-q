(function () {
  if (window.__tmdInjected) return;
  window.__tmdInjected = true;

  let armed = false;
  let reportedKey = false;
  let continuing = false;
  let lastToken = '';
  let cleaned = false;
  let reportedUnlock = '';
  let cleanTries = 0;
  let ALLOWED = null;
  let holderEl = null;
  let capRef = null;
  let btnWrap = null;

  const OUR_HOSTS = /(^|\.)(unlock\.tumadam\.com|authtool\.app)$/i;
  const UNLOCK_RE = /https?:\/\/unlock\.tumadam\.com\/[A-Za-z0-9]{6,}\.html/i;
  const PROVIDER_RE = /(^|\.)(google\.com|recaptcha\.net|hcaptcha\.com|newassets\.hcaptcha\.com|challenges\.cloudflare\.com|cloudflare\.com|doubleclick\.net|googleadservices\.com)$/i;
  const IS_TOP = window.top === window;

  const STRONG_CAP_SEL = '.cf-turnstile,[data-sitekey],[data-turnstile-sitekey],.g-recaptcha,.h-captcha,#captcha,.captcha-container,iframe[src*="recaptcha"],iframe[src*="hcaptcha"],iframe[src*="challenges.cloudflare"],iframe[src*="captcha"],iframe[title*="captcha" i]';
  const WEAK_CAP_SEL = '[class*="captcha" i],[id*="captcha" i]';
  const CAPTCHA_SEL = STRONG_CAP_SEL + ',' + WEAK_CAP_SEL;

  const TOKEN_SEL = [
    'textarea[name="g-recaptcha-response"]',
    'textarea[id^="g-recaptcha-response"]',
    'textarea[id^="recaptcha-token"]',
    'input[name="cf-turnstile-response"]',
    'input[id^="cf-turnstile-response"]',
    'textarea[name="h-captcha-response"]',
    'textarea[id^="h-captcha-response"]',
    'input[name="h-captcha-response"]',
    'textarea[data-hcaptcha-response]',
    '[name*="turnstile"]',
    '[name*="captcha"][type="hidden"]'
  ].join(',');

  const KEEP_BTN_SEL = 'button, input[type="submit"], input[type="button"], a, [role="button"], [onclick], .btn';
  const KEEP_TEXT_RE = /(xác\s*minh|xac\s*minh|xác\s*thực|xac\s*thuc|lấy\s*key|lay\s*key|get\s*key|lấy\s*link|lay\s*link|get\s*link|verify|submit|confirm|tiếp\s*tục|tiep\s*tuc|kiểm\s*tra|kiem\s*tra|next|bắt\s*đầu|bat\s*dau)/i;

  function sendBg(data, cb) {
    try {
      chrome.runtime.sendMessage({ type: 'FROM_CONTENT', data: data }, function (r) {
        void chrome.runtime.lastError;
        if (cb) cb(r);
      });
    } catch (e) { if (cb) cb(null); }
  }

  function log(msg) { sendBg({ kind: 'LOG', msg: msg }); }

  function extractKey(text) {
    let s = text;
    try { s = decodeURIComponent(text); } catch (e) {}
    let m = s.match(/result=([A-Za-z0-9_.\-]+)/);
    if (m && m[1].indexOf('tumadam') === 0) return m[1];
    m = s.match(/result=(tumadam[-\w.]+)/);
    if (m) return m[1];
    m = s.match(/(tumadam(?:-\w+)+-\w+)/);
    if (m) return m[1];
    return null;
  }

  function apiToken() {
    try { if (window.grecaptcha && typeof window.grecaptcha.getResponse === 'function') { const r = window.grecaptcha.getResponse(); if (r) return r; } } catch (e) {}
    try { if (window.hcaptcha && typeof window.hcaptcha.getResponse === 'function') { const r = window.hcaptcha.getResponse(); if (r) return r; } } catch (e) {}
    try { if (window.turnstile && typeof window.turnstile.getResponse === 'function') { const r = window.turnstile.getResponse(); if (r) return r; } } catch (e) {}
    return '';
  }

  function readToken() {
    const a = apiToken();
    if (a) return a;
    const els = document.querySelectorAll(TOKEN_SEL);
    for (const el of els) {
      const v = (el.value || el.textContent || '').trim();
      if (v.length > 10) return v;
    }
    return '';
  }

  function isOurUI(el) {
    if (!el || el.nodeType !== 1) return true;
    return el.id === 'tmd-tip' || el.id === 'tmd-key-box' || el.id === 'tmd-holder' || el.id === 'tmd-btns';
  }

  function findCaptcha() {
    const el = document.querySelector(STRONG_CAP_SEL);
    if (!el || isOurUI(el) || !el.isConnected) return null;
    return el;
  }

  function buildAllowed(root) {
    const set = new Set();
    let n = root;
    while (n && n !== document.documentElement) { set.add(n); n = n.parentElement; }
    root.querySelectorAll('*').forEach(function (x) { set.add(x); });
    return set;
  }

  function nodeMatchesKeep(el) {
    if (!el || el.nodeType !== 1 || isOurUI(el)) return false;
    try { if (!el.matches(KEEP_BTN_SEL)) return false; } catch (e) { return false; }
    const t = (el.innerText || el.value || el.placeholder || '').trim();
    return !!(t && KEEP_TEXT_RE.test(t));
  }

  function ensureBtnWrap() {
    if (btnWrap && btnWrap.isConnected) return btnWrap;
    btnWrap = document.createElement('div');
    btnWrap.id = 'tmd-btns';
    btnWrap.style.cssText = 'display:flex;flex-direction:column;align-items:center;gap:10px;margin-top:18px';
    return btnWrap;
  }

  function adoptIfKeep(el) {
    const targets = [];
    if (nodeMatchesKeep(el) && ALLOWED && !ALLOWED.has(el)) targets.push(el);
    if (el.querySelectorAll) {
      el.querySelectorAll(KEEP_BTN_SEL).forEach(function (b) {
        if (nodeMatchesKeep(b) && ALLOWED && !ALLOWED.has(b)) targets.push(b);
      });
    }
    if (!targets.length) return false;
    const bw = ensureBtnWrap();
    for (const t of targets) { bw.appendChild(t); ALLOWED.add(t); }
    return true;
  }

  function handleStray(el) {
    if (!el || !el.isConnected || el.nodeType !== 1) return;
    if (isOurUI(el)) return;
    if (ALLOWED && ALLOWED.has(el)) return;
    if (btnWrap && btnWrap.contains(el)) return;
    if (adoptIfKeep(el)) return;
    try { el.remove(); } catch (e) {}
  }

  function sweep() {
    if (!document.body || !ALLOWED) return;
    const all = Array.prototype.slice.call(document.body.querySelectorAll('*'));
    for (const el of all) handleStray(el);
  }

  function findKeepButtons(cap) {
    const out = [];
    const els = document.querySelectorAll(KEEP_BTN_SEL);
    for (const el of els) {
      if (!el.isConnected || isOurUI(el)) continue;
      if (cap !== el && cap.contains(el)) continue;
      if (nodeMatchesKeep(el)) out.push(el);
    }
    return out;
  }

  function addTip(text) {
    if (!IS_TOP) return;
    let tip = document.getElementById('tmd-tip');
    if (!tip) {
      tip = document.createElement('div');
      tip.id = 'tmd-tip';
      tip.style.cssText = 'position:fixed;top:18px;left:50%;transform:translateX(-50%);z-index:2147483647;background:#2563eb;color:#fff;padding:10px 18px;border-radius:999px;font:600 13px/1.4 system-ui,sans-serif;white-space:nowrap;box-shadow:0 4px 18px rgba(0,0,0,.45)';
      (document.body || document.documentElement).appendChild(tip);
    }
    tip.textContent = text;
  }

  function cleanPage() {
    if (cleaned || !document.body) return false;
    const cap = findCaptcha();
    if (!cap) return false;
    capRef = cap;
    const btns = findKeepButtons(cap);
    holderEl = document.createElement('div');
    holderEl.id = 'tmd-holder';
    holderEl.style.cssText = 'position:fixed;top:50%;left:50%;transform:translate(-50%,-52%);z-index:2147483646;display:flex;flex-direction:column;align-items:center;background:#0f1420;padding:20px;border-radius:16px;max-height:96vh;overflow:auto';
    holderEl.appendChild(cap);
    if (btns.length) {
      const bw = ensureBtnWrap();
      for (const b of btns) bw.appendChild(b);
      holderEl.appendChild(bw);
    }
    document.body.textContent = '';
    for (const el of Array.prototype.slice.call(document.documentElement.children)) {
      if (el.tagName === 'BODY' || el.tagName === 'HEAD') continue;
      try { el.remove(); } catch (e) {}
    }
    applyDark();
    document.body.appendChild(holderEl);
    ALLOWED = buildAllowed(holderEl);
    addTip('Vuot captcha roi bam Lay key - tool tu bat link');
    cleaned = true;
    log('Da xoa trang. Giu: CAPTCHA + ' + btns.length + ' nut hanh dong.');
    return true;
  }

  function applyDark() {
    document.body.style.setProperty('background', '#0f1420', 'important');
    document.documentElement.style.setProperty('overflow', 'hidden', 'important');
  }

  setInterval(function () {
    if (!cleaned || !holderEl || IS_TOP === false && !capRef) return;
    if (!document.body) return;
    if (!holderEl.isConnected || (capRef && !capRef.isConnected) || !document.body.contains(holderEl)) {
      try {
        document.body.textContent = '';
        applyDark();
        document.body.appendChild(holderEl);
        log('Web da ghi de trang - DA KHOI PHUC lai captcha.');
      } catch (e) {}
    }
  }, 300);

  function showKeyBox(key) {
    if (!IS_TOP) return;
    const old = document.getElementById('tmd-key-box');
    if (old) old.remove();
    const tip = document.getElementById('tmd-tip');
    if (tip) tip.remove();
    const box = document.createElement('div');
    box.id = 'tmd-key-box';
    box.style.cssText = 'position:fixed;left:50%;bottom:28px;transform:translateX(-50%);z-index:2147483647;background:linear-gradient(135deg,#16a34a,#15803d);color:#fff;padding:14px 22px;border-radius:14px;font-family:system-ui,sans-serif;box-shadow:0 8px 32px rgba(0,0,0,.55);text-align:center;cursor:pointer;max-width:94vw';
    const l = document.createElement('div');
    l.textContent = 'KEY CỦA BẠN';
    l.style.cssText = 'font-size:10px;font-weight:700;letter-spacing:.12em;opacity:.85;margin-bottom:4px';
    const v = document.createElement('div');
    v.className = 'tmd-key-val';
    v.textContent = key;
    v.title = 'Bam de copy';
    v.style.cssText = 'font:700 15px/1.4 ui-monospace,monospace;word-break:break-all;user-select:all';
    v.addEventListener('click', function () {
      if (navigator.clipboard) navigator.clipboard.writeText(key);
      v.textContent = 'DA COPY!';
      setTimeout(function () { v.textContent = key; }, 1200);
    });
    (document.body || document.documentElement).appendChild(box);
  }

  function reportKey(key) {
    if (!key || reportedKey) return;
    reportedKey = true;
    showKeyBox(key);
    sendBg({ kind: 'KEY', key: key, url: location.href });
  }

  function findDest() {
    const html = document.documentElement.innerHTML;
    const m = html.match(/DEST\s*=\s*"([^"]+)"/);
    if (!m) return null;
    let d = m[1];
    if (d.indexOf('/') === 0) d = location.origin + d;
    return d;
  }

  function activeContinue(token) {
    let dest = findDest();
    if (!dest) {
      log('Khong thay DEST trong trang HTML.');
      const f = document.querySelector('form');
      if (f) {
        log('Gui form cua trang di tiep...');
        try { f.submit(); } catch (e) {}
        return;
      }
      continuing = false;
      return;
    }
    try {
      const u = new URL(dest);
      u.searchParams.set('token', token);
      u.searchParams.set('captcha_token', token);
      u.searchParams.set('cf-turnstile-response', token);
      u.searchParams.set('g-recaptcha-response', token);
      u.searchParams.set('h-captcha-response', token);
      dest = u.toString();
    } catch (e) {}
    log('Lay token xong (' + token.length + ' ky tu), di tiep...');
    addTip('Dang xu ly lay key...');
    fetch(dest, { credentials: 'include', redirect: 'follow' })
      .then(function (r) { return r.text().then(function (t) { return { url: r.url, text: t }; }); })
      .then(function (res) {
        let key = extractKey(res.url) || extractKey(res.text);
        if (!key) {
          const mm = res.text.match(/https?:\/\/[^'"\s<>]*result=[^'"\s<>]+/);
          if (mm) key = extractKey(mm[0]);
        }
        if (key) reportKey(key);
        else {
          log('Chua thay key, mo truc tiep DEST...');
          location.href = dest;
        }
      })
      .catch(function (e) {
        log('Fetch loi (' + e.message + '), chuyen huong truc tiep...');
        location.href = dest;
      });
  }

  function scanUnlock() {
    if (!armed || reportedUnlock === '__sent__') return;
    let html = '';
    try { html = document.documentElement.innerHTML; } catch (e) { return; }
    const m = html.match(UNLOCK_RE);
    if (m && m[0] !== reportedUnlock) {
      reportedUnlock = m[0];
      log('BAT DUOC LINK UNLOCK: ' + m[0]);
      addTip('Da bat link unlock! Dang xu ly...');
      sendBg({ kind: 'UNLOCK', url: m[0], pageUrl: location.href }, function () {
        reportedUnlock = '__sent__';
      });
    }
  }

  function arm() {
    if (armed) return;
    armed = true;
    log('Tool ACTIVE (' + (IS_TOP ? 'top' : 'frame') + '): ' + location.host);
    startWatchers();
    const boot = setInterval(function () {
      if (cleanPage()) clearInterval(boot);
    }, 400);
    setTimeout(function () {
      if (!IS_TOP) return;
      if (armed && !cleaned && !continuing && !reportedKey) {
        const d = findDest();
        if (d) {
          log('Trang nay khong co captcha, tu dong qua DEST...');
          location.href = d;
        }
      }
    }, 4000);
  }

  function startWatchers() {
    const mo = new MutationObserver(function (muts) {
      if (!cleaned) { cleanPage(); return; }
      for (const m of muts) {
        m.addedNodes.forEach(function (n) {
          if (n.nodeType !== 1) return;
          handleStray(n);
        });
        for (const n of Array.prototype.slice.call(document.body.children)) {
          handleStray(n);
        }
      }
    });

    const ready = setInterval(function () {
      if (!document.body) return;
      clearInterval(ready);
      mo.observe(document.documentElement, { childList: true, subtree: true });
    }, 200);

    setInterval(function () {
      if (!cleaned) cleanPage();
      else sweep();
    }, 800);

    setInterval(function () {
      if (reportedKey || continuing) return;
      const t = readToken();
      if (t && t !== lastToken) {
        lastToken = t;
        continuing = true;
        log('PHAT HIEN captcha da giai! Lay token va tiep tuc...');
        setTimeout(function () { activeContinue(t); }, 400);
      }
    }, 300);

    document.addEventListener('click', function () {
      if (!armed || continuing || reportedKey) return;
      setTimeout(function () {
        const t = readToken();
        if (t && t !== lastToken) {
          lastToken = t;
          continuing = true;
          log('Bat duoc token sau khi bam nut, tiep tuc...');
          setTimeout(function () { activeContinue(t); }, 300);
        }
      }, 250);
    }, true);

    document.addEventListener('tmd-api-key', function (e) {
      const d = e.detail || {};
      if (d.key) {
        log('Bat duoc key tu API mang: ' + d.key);
        reportKey(d.key);
      }
    });

    setInterval(function () {
      try {
        const v = sessionStorage.getItem('tmd_api_key');
        if (v) reportKey(v);
      } catch (e) {}
    }, 500);

    setInterval(function () {
      try {
        const nav = performance.getEntriesByType('navigation')[0];
        if (nav && nav.name) {
          const k1 = extractKey(nav.name);
          if (k1) reportKey(k1);
        }
        const res = performance.getEntriesByType('resource');
        for (const r of res) {
          const k2 = extractKey(r.name);
          if (k2) { reportKey(k2); break; }
        }
      } catch (e) {}
    }, 500);

    setInterval(function () {
      const k = extractKey(location.href);
      if (k) reportKey(k);
    }, 500);

    const KEY_TEXT_RE = /(tumadam(?:-\w+)+-\w+)/;
    setInterval(function () {
      if (reportedKey || !document.body) return;
      let m = null;
      try { m = KEY_TEXT_RE.exec(document.body.innerText || ''); } catch (e) {}
      if (!m) { try { m = KEY_TEXT_RE.exec(document.documentElement.innerHTML); } catch (e) {} }
      if (m) {
        log('Thay key hien tren man hinh: ' + m[1]);
        reportKey(m[1]);
      }
    }, 500);

    const clicked = new Set();
    setInterval(function () {
      if (!armed || cleaned || reportedKey || continuing) return;
      if (!OUR_HOSTS.test(location.hostname)) return;
      const els = document.querySelectorAll('button, [role="button"], a, input[type="submit"], input[type="button"], .btn, [onclick]');
      for (const el of els) {
        if (clicked.has(el) || !el.isConnected || el.disabled) continue;
        const r = el.getBoundingClientRect();
        if (r.width < 30 || r.height < 15) continue;
        const t = (el.innerText || el.value || '').trim();
        if (t && KEEP_TEXT_RE.test(t)) {
          clicked.add(el);
          log('Tu dong bam nut: ' + t.slice(0, 40));
          try { el.click(); } catch (e) {}
          break;
        }
      }
    }, 800);

    setInterval(scanUnlock, 400);
  }

  let pingTries = 0;

  function ping() {
    if (armed) return;
    if (PROVIDER_RE.test(location.hostname)) return;
    if (OUR_HOSTS.test(location.hostname)) { arm(); return; }
    try {
      chrome.runtime.sendMessage({ type: 'IS_RUNNING' }, function (r) {
        void chrome.runtime.lastError;
        if (r && r.running) arm();
      });
    } catch (e) {}
    if (++pingTries > 60) clearInterval(pingTimer);
  }

  const pingTimer = setInterval(ping, 2000);
  ping();

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', ping);
  }
})();
