(function () {
  const m = location.search.match(/[?&]tmdkey=([^&]+)/);
  if (!m) return;
  const KEY = decodeURIComponent(m[1]);

  function msg(kind, extra) {
    try {
      chrome.runtime.sendMessage({ type: 'FROM_CONTENT', data: Object.assign({ kind: kind }, extra || {}) }, function () { void chrome.runtime.lastError; });
    } catch (e) {}
  }

  function getExpire() {
    try {
      const saved = localStorage.getItem('user_input_code');
      if (saved) {
        const e = localStorage.getItem('expire_time_' + saved);
        if (e && parseInt(e, 10) > Date.now()) return parseInt(e, 10);
      }
    } catch (err) {}
    return Date.now() + 30 * 86400000;
  }

  function startLocalTimer() {
    if (window.__tmdTimer) return;
    const exp = getExpire();
    window.__tmdTimer = setInterval(function () {
      const el = document.getElementById('time-remaining');
      if (!el) return;
      const diff = exp - Date.now();
      if (diff <= 0) { el.innerText = 'Hết hạn'; return; }
      const d = Math.floor(diff / 86400000);
      const h = Math.floor((diff % 86400000) / 3600000);
      const mi = Math.floor((diff % 3600000) / 60000);
      const s = Math.floor((diff % 60000) / 1000);
      el.innerText = (d > 0 ? d + 'd ' : '') + h + 'h ' + mi + 'm ' + s + 's';
    }, 1000);
  }

  function forceShow() {
    const lb = document.getElementById('login-box');
    const ac = document.getElementById('app-content');
    const disp = document.getElementById('user-key-display');
    const err = document.getElementById('error-msg');
    if (!lb || !ac || !disp) return false;
    if (err) err.innerText = '';
    lb.classList.remove('active');
    ac.classList.add('active');
    disp.innerText = KEY;
    startLocalTimer();
    banner();
    return true;
  }

  function banner() {
    if (document.getElementById('tmd-banner')) return;
    const b = document.createElement('div');
    b.id = 'tmd-banner';
    b.style.cssText = 'position:fixed;left:50%;bottom:14px;transform:translateX(-50%);z-index:2147483647;background:#2563eb;color:#fff;padding:8px 16px;border-radius:999px;font:600 12px system-ui,sans-serif;white-space:nowrap;box-shadow:0 4px 18px rgba(0,0,0,.45)';
    b.textContent = 'TMD TOOL da nap key - tab giu den khi ban dong';
    document.body.appendChild(b);
  }

  function guardian() {
    setInterval(function () {
      const ac = document.getElementById('app-content');
      if (!ac) return;
      if (!ac.classList.contains('active')) forceShow();
      else banner();
      const disp = document.getElementById('user-key-display');
      if (disp && disp.innerText.trim() === '---') disp.innerText = KEY;
    }, 1200);
  }

  function run() {
    try { history.replaceState(null, '', '/'); } catch (e) {}
    let tries = 0;
    const t = setInterval(function () {
      tries++;
      const inp = document.getElementById('key-input');
      const btn = document.getElementById('login-btn');
      if (inp && btn && document.getElementById('app-content')) {
        clearInterval(t);
        try {
          inp.value = KEY;
          inp.dispatchEvent(new Event('input', { bubbles: true }));
          btn.click();
        } catch (e) {}
        msg('LOG', { msg: '[vercel] Da nap key: ' + KEY });
        setTimeout(forceShow, 400);
        guardian();
      } else if (tries > 80) {
        clearInterval(t);
      }
    }, 250);
  }

  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', run);
  else run();
})();
