const GETKEY_PAGE = 'https://unlock.tumadam.com/getkeylqm.html';
const LINK_TIMEOUT_MS = 150000;

let S = freshState();
let stepping = false;

function freshState() {
  return { running: false, queue: [], index: 0, total: 0, keys: [], fails: [], logs: [], tabId: null, vercelTabId: null, startedAt: 0 };
}

async function tabAlive(id) {
  if (id == null) return false;
  try {
    const t = await chrome.tabs.get(id);
    return !!t;
  } catch (e) { return false; }
}

function extractKey(text) {
  let s = text;
  try { s = decodeURIComponent(text); } catch (e) {}
  let m = s.match(/result=([A-Za-z0-9_.\-]+)/);
  if (m && m[1].indexOf('tumadam') === 0) return m[1];
  m = s.match(/result=(tumadam[-\w.]+)/);
  if (m) return m[1];
  m = s.match(/(tumadam(?:-\w+)+-\w+)/);
  if (m) return m[1];
  return null;
}

function snapshot() {
  return {
    running: S.running,
    done: Math.min(S.index, S.total),
    total: S.total,
    keys: S.keys.slice(),
    fails: S.fails.slice(),
    logs: S.logs.slice(-80),
    current: S.queue[S.index] || null
  };
}

function broadcast() {
  try {
    chrome.runtime.sendMessage({ type: 'STATE', state: snapshot() }, function () { void chrome.runtime.lastError; });
  } catch (e) {}
}

function log(msg) {
  const d = new Date();
  const ts = ('0' + d.getHours()).slice(-2) + ':' + ('0' + d.getMinutes()).slice(-2) + ':' + ('0' + d.getSeconds()).slice(-2);
  S.logs.push(ts + '  ' + msg);
  if (S.logs.length > 300) S.logs.shift();
  persist(); broadcast();
}

async function persist() {
  const c = Object.assign({}, S);
  await chrome.storage.local.set({ tmdState: c });
}

async function restore() {
  const o = await chrome.storage.local.get('tmdState');
  if (o && o.tmdState) S = Object.assign(freshState(), o.tmdState);
}

async function start(count) {
  if (S.running) return { ok: false, error: 'Tool dang chay roi.' };
  log('Dang tai danh sach link tu getkeylqm.html ...');
  let html = '';
  try {
    const r = await fetch(GETKEY_PAGE, { headers: { 'Accept-Language': 'vi-VN,vi;q=0.9' } });
    html = await r.text();
  } catch (e) {
    log('[X] Khong tai duoc trang getkey: ' + e.message);
    return { ok: false, error: 'Khong tai duoc trang getkey' };
  }
  const seen = {}; const found = [];
  const ms = html.match(/https:\/\/authtool\.app\/get-key\?code=[^'"\s<>]+/g) || [];
  for (const l of ms) { if (!seen[l]) { seen[l] = 1; found.push(l); } }
  if (!found.length) { log('[X] Khong tim thay link goc nao.'); return { ok: false, error: 'Khong tim thay link goc' }; }
  log('[+] Tim thay ' + found.length + ' link goc.');

  const st = await chrome.storage.local.get({ linkvuot: [] });
  const existing = {};
  st.linkvuot.forEach(function (l) { existing[l] = 1; });
  const news = [];
  let idx = 1;
  while (news.length < count && idx <= count * 10 + 100) {
    const base = found[(idx - 1) % found.length];
    let cand = base;
    if (idx > found.length) cand += (base.indexOf('?') >= 0 ? '&' : '?') + 'idx=' + idx;
    if (!existing[cand] && news.indexOf(cand) === -1) news.push(cand);
    idx++;
  }
  if (!news.length) { log('[!] Khong tao duoc link moi (tat ca da co san).'); return { ok: false, error: 'Khong co link moi' }; }
  await chrome.storage.local.set({ linkvuot: st.linkvuot.concat(news) });
  log('[+] Da tao ' + news.length + ' link vuot moi.');

  S = freshState();
  S.running = true;
  S.queue = news;
  S.total = news.length;
  await persist();
  openNext();
  return { ok: true };
}

async function openNext() {
  if (!S.running) return;
  if (S.index >= S.queue.length) return finish();
  const url = S.queue[S.index];
  log('[*] Xu ly link ' + (S.index + 1) + '/' + S.total + ' ...');
  try {
    if (await tabAlive(S.tabId)) {
      await chrome.tabs.update(S.tabId, { url: url });
    } else {
      const tab = await chrome.tabs.create({ url: url, active: true });
      S.tabId = tab.id;
    }
  } catch (e) { S.tabId = null; }
  S.startedAt = Date.now();
  await persist(); broadcast();
  setTimeout(async function () {
    if (S.running && S.tabId != null && Date.now() - S.startedAt >= LINK_TIMEOUT_MS - 2000) {
      log('[!] Qua thoi gian cho, bo qua link nay.');
      S.fails.push(S.queue[S.index]);
      await stepDone();
    }
  }, LINK_TIMEOUT_MS);
}

async function stepDone() {
  if (stepping) return;
  stepping = true;
  S.index++;
  stepping = false;
  await persist();
  openNext();
}

async function finish() {
  S.running = false;
  S.tabId = null;
  log('=== HOAN THANH: lay duoc ' + S.keys.length + '/' + S.total + ' key ===');
  await persist(); broadcast();
}

async function gotKey(key, fromRunningFlowOnly) {
  if (stepping) return false;
  stepping = true;
  if (S.keys.indexOf(key) === -1) {
    S.keys.push(key);
    log('[+] KEY: ' + key);
    const st = await chrome.storage.local.get({ keys: [] });
    const list = st.keys.map(function (x) { return typeof x === 'string' ? { k: x, t: null } : x; });
    if (!list.some(function (x) { return x.k === key; })) list.push({ k: key, t: Date.now() });
    await chrome.storage.local.set({ keys: list });
    try {
      const vurl = 'https://severkey-h.vercel.app/?tmdkey=' + encodeURIComponent(key);
      if (await tabAlive(S.vercelTabId)) {
        await chrome.tabs.update(S.vercelTabId, { url: vurl });
      } else {
        const vt = await chrome.tabs.create({ url: vurl, active: false });
        S.vercelTabId = vt.id;
      }
      log('[+] Da nap key vao tab severkey (dung 1 tab duy nhat).');
      await persist();
    } catch (e) {}
  } else {
    log('[=] Key trung, bo qua.');
  }
  stepping = false;
  if (S.running) stepDone();
  broadcast();
  return true;
}

chrome.tabs.onUpdated.addListener(function (tabId, info) {
  if (!S.running || tabId !== S.tabId) return;
  if (info.url) {
    log('[tab] ' + info.url.slice(0, 130));
    const k = extractKey(info.url);
    if (k) gotKey(k);
  }
});

setInterval(async function () {
  if (!S.running || S.index >= S.queue.length) return;
  if (Date.now() - (S.startedAt || 0) < 6000) return;
  if (S.tabId == null || !(await tabAlive(S.tabId))) {
    log('[!] Phat hien luong bi dung - tu dong mo lai link.');
    S.tabId = null;
    await persist();
    openNext();
  }
}, 4000);

chrome.runtime.onMessage.addListener(function (msg, sender, sendResponse) {
  (async function () {
    if (msg.type === 'START') {
      await restore();
      sendResponse(await start(Math.max(1, Math.min(500, msg.count | 0))));
      return;
    }
    if (msg.type === 'STOP') {
      await restore();
      S.running = false;
      if (S.tabId != null) { try { await chrome.tabs.remove(S.tabId); } catch (e) {} S.tabId = null; }
      log('[!] Nguoi dung da dung tool.');
      await persist(); broadcast();
      sendResponse({ ok: true });
      return;
    }
    if (msg.type === 'CLEAR_KEYS') {
      await chrome.storage.local.set({ keys: [] });
      sendResponse({ ok: true });
      return;
    }
    if (msg.type === 'GET_STATE') {
      await restore();
      const ks = await chrome.storage.local.get({ keys: [] });
      const snap = snapshot();
      snap.savedKeys = ks.keys;
      sendResponse({ ok: true, state: snap });
      return;
    }
    if (msg.type === 'IS_RUNNING') {
      await restore();
      sendResponse({ running: S.running });
      return;
    }
    if (msg.type === 'FROM_CONTENT') {
      await restore();
      const d = msg.data || {};
      if (d.kind === 'KEY' && d.key) {
        const ok = await gotKey(d.key);
        sendResponse({ ok: ok });
      } else if (d.kind === 'UNLOCK' && d.url) {
        const st = await chrome.storage.local.get({ linkvuot: [] });
        if (st.linkvuot.indexOf(d.url) === -1) {
          st.linkvuot.push(d.url);
          await chrome.storage.local.set({ linkvuot: st.linkvuot });
          log('[unlock] Da luu link: ' + d.url);
        }
        if (S.running && S.tabId != null) {
          try { await chrome.tabs.update(S.tabId, { url: d.url }); } catch (e) {}
        }
        sendResponse({ ok: true });
      } else if (d.kind === 'CLOSE_TAB' && sender.tab && sender.tab.id != null) {
        try { await chrome.tabs.remove(sender.tab.id); } catch (e) {}
        log('[vercel] Da dong tab nap key.');
        sendResponse({ ok: true });
      } else if (d.kind === 'LOG') {
        log('[page] ' + d.msg);
        sendResponse({ ok: true });
      } else {
        sendResponse({ ok: false });
      }
      return;
    }
    sendResponse({ ok: false });
  })();
  return true;
});
