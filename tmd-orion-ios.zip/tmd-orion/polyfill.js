/* polyfill.js — Orion iOS / Safari WebExtension compatibility shim */
(function () {
  'use strict';

  // --- Step 1: Make sure `chrome` exists ---
  var _api = null;
  if (typeof browser !== 'undefined' && browser && browser.runtime) {
    _api = browser;
  } else if (typeof chrome !== 'undefined' && chrome && chrome.runtime) {
    _api = chrome;
  }

  if (!_api) {
    // Neither available (e.g. normal web page context) — create a stub so code doesn't crash
    _api = _makeStub();
  }

  // Expose as both `chrome` and `browser`
  try { window.chrome = _api; } catch(e) {}
  try { window.browser = _api; } catch(e) {}

  // --- Step 2: Patch storage.session → storage.local ---
  if (_api.storage && !_api.storage.session) {
    _api.storage.session = _api.storage.local;
  }

  // --- Step 3: Fix runtime.lastError access ---
  if (_api.runtime && typeof _api.runtime.lastError === 'undefined') {
    Object.defineProperty(_api.runtime, 'lastError', {
      get: function() { return null; },
      configurable: true
    });
  }

  // --- Stub factory (last resort) ---
  function _noop() {}
  function _noopCb(obj, cb) { if (typeof cb === 'function') cb({}); }
  function _makeStub() {
    return {
      runtime: {
        sendMessage: function(msg, cb) { if (cb) cb({}); },
        onMessage: { addListener: _noop, removeListener: _noop },
        lastError: null,
        id: 'stub'
      },
      storage: {
        local: {
          get: function(def, cb) { if (cb) cb(typeof def === 'object' ? def : {}); },
          set: function(obj, cb) { if (cb) cb(); },
          remove: function(key, cb) { if (cb) cb(); }
        },
        session: {
          get: function(def, cb) { if (cb) cb(typeof def === 'object' ? def : {}); },
          set: function(obj, cb) { if (cb) cb(); },
          remove: function(key, cb) { if (cb) cb(); }
        }
      },
      tabs: {
        create: function(opts, cb) { if (cb) cb({ id: -1 }); return Promise.resolve({ id: -1 }); },
        update: function(id, opts, cb) { if (cb) cb(); return Promise.resolve(); },
        get: function(id, cb) { if (cb) cb(null); return Promise.resolve(null); },
        remove: function(id, cb) { if (cb) cb(); return Promise.resolve(); }
      }
    };
  }
})();
