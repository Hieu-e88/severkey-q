/* Storage wrapper: chrome.storage.local with localStorage fallback for Orion iOS */
(function() {
  function promisifyGet(store, keys, defaults) {
    return new Promise(function(resolve) {
      try {
        store.get(defaults, function(r) {
          void (typeof chrome !== 'undefined' && chrome.runtime && chrome.runtime.lastError);
          resolve(r || defaults || {});
        });
      } catch(e) {
        // localStorage fallback
        var result = Object.assign({}, defaults || {});
        if (typeof keys === 'string') {
          try { var v = localStorage.getItem('tmd_' + keys); if (v !== null) result[keys] = JSON.parse(v); } catch(e2) {}
        } else if (Array.isArray(keys)) {
          keys.forEach(function(k) { try { var v = localStorage.getItem('tmd_' + k); if (v !== null) result[k] = JSON.parse(v); } catch(e2) {} });
        } else if (keys && typeof keys === 'object') {
          Object.keys(keys).forEach(function(k) { try { var v = localStorage.getItem('tmd_' + k); if (v !== null) result[k] = JSON.parse(v); } catch(e2) {} });
        }
        resolve(result);
      }
    });
  }

  function promisifySet(store, obj) {
    return new Promise(function(resolve) {
      try {
        store.set(obj, function() {
          void (typeof chrome !== 'undefined' && chrome.runtime && chrome.runtime.lastError);
          resolve();
        });
      } catch(e) {
        Object.keys(obj).forEach(function(k) { try { localStorage.setItem('tmd_' + k, JSON.stringify(obj[k])); } catch(e2) {} });
        resolve();
      }
    });
  }

  function promisifyRemove(store, key) {
    return new Promise(function(resolve) {
      try {
        store.remove(key, function() {
          void (typeof chrome !== 'undefined' && chrome.runtime && chrome.runtime.lastError);
          resolve();
        });
      } catch(e) {
        var keys = Array.isArray(key) ? key : [key];
        keys.forEach(function(k) { try { localStorage.removeItem('tmd_' + k); } catch(e2) {} });
        resolve();
      }
    });
  }

  // Patch chrome.storage.local to return promises AND accept callbacks
  if (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.local) {
    var orig = chrome.storage.local;
    window._tmdStorage = {
      get: function(def, cb) {
        var p = promisifyGet(orig, def, def);
        if (cb) p.then(cb);
        return p;
      },
      set: function(obj, cb) {
        var p = promisifySet(orig, obj);
        if (cb) p.then(cb);
        return p;
      },
      remove: function(key, cb) {
        var p = promisifyRemove(orig, key);
        if (cb) p.then(cb);
        return p;
      }
    };
    chrome.storage.local = window._tmdStorage;
    if (!chrome.storage.session) chrome.storage.session = window._tmdStorage;
  }
})();
const KEY_URL = 'https://raw.githubusercontent.com/Hieu-e88/severkey-q/refs/heads/main/Key_tc.txt';
const DAY_MS = 86400000;

const $ = function (id) { return document.getElementById(id); };

function send(msg) {
  return new Promise(function (res) {
    chrome.runtime.sendMessage(msg, function (r) { void chrome.runtime.lastError; res(r || {}); });
  });
}

function show(view) {
  $('view-login').classList.toggle('hidden', view !== 'login');
  $('view-main').classList.toggle('hidden', view !== 'main');
}

async function fetchKeys() {
  const r = await fetch(KEY_URL, { cache: 'no-store' });
  if (!r.ok) throw new Error('HTTP ' + r.status);
  return r.text();
}

function parseKeys(text) {
  const out = [];
  for (let line of text.split(/\r?\n/)) {
    const m = line.match(/^(.+?)\.(\d+)\s*\|\s*(.*)$/);
    if (m) out.push({ code: m[1].trim(), days: parseInt(m[2], 10), message: m[3].trim() });
  }
  return out;
}

async function login(code) {
  let text;
  try { text = await fetchKeys(); }
  catch (e) { return { ok: false, error: 'Khong tai duoc danh sach key!' }; }
  const entries = parseKeys(text);
  let found = null;
  for (const e of entries) if (e.code.toLowerCase() === code.toLowerCase()) { found = e; break; }
  if (!found) return { ok: false, error: 'Sai ma xac minh!' };

  const st = await chrome.storage.local.get({ activations: {} });
  const acts = st.activations;
  const now = Date.now();
  let first = now;
  if (acts[code] && typeof acts[code].first === 'number') first = acts[code].first;
  else { acts[code] = { first: now }; await chrome.storage.local.set({ activations: acts }); }

  const expireAt = first + found.days * DAY_MS;
  if (now >= expireAt) {
    delete acts[code];
    await chrome.storage.local.set({ activations: acts });
    return { ok: false, error: 'Key da het han!' };
  }
  const remainDays = Math.max(0, Math.ceil((expireAt - now) / DAY_MS));
  await chrome.storage.local.set({ authed: { code: code, expireAt: expireAt, days: found.days } });
  return { ok: true, message: found.message, remainDays: remainDays };
}

async function boot() {
  const st = await chrome.storage.local.get({ authed: null });
  if (st.authed && st.authed.expireAt > Date.now()) {
    enterMain(st.authed.code);
    return;
  }
  if (st.authed) await chrome.storage.local.remove('authed');
  show('login');
}

let cdTimer = null;
let renewTimer = null;

function fmtRemain(ms) {
  const s = Math.max(0, Math.floor(ms / 1000));
  const d = Math.floor(s / 86400);
  const h = Math.floor((s % 86400) / 3600);
  const m = Math.floor((s % 3600) / 60);
  const ss = s % 60;
  const p = function (x) { return String(x).padStart(2, '0'); };
  return d + ' ngày ' + p(h) + ':' + p(m) + ':' + p(ss);
}

function stopTimers() {
  if (cdTimer) { clearInterval(cdTimer); cdTimer = null; }
  if (renewTimer) { clearInterval(renewTimer); renewTimer = null; }
}

function startCountdown() {
  if (cdTimer) clearInterval(cdTimer);
  async function tick() {
    const st = await chrome.storage.local.get({ authed: null });
    if (!st.authed || st.authed.expireAt <= Date.now()) {
      await chrome.storage.local.remove('authed');
      stopTimers();
      show('login');
      return;
    }
    $('cd-time').textContent = fmtRemain(st.authed.expireAt - Date.now());
  }
  tick();
  cdTimer = setInterval(tick, 1000);
}

async function checkRenewal() {
  const st = await chrome.storage.local.get({ authed: null });
  if (!st.authed) return;
  let text;
  try { text = await fetchKeys(); } catch (e) { return; }
  const entries = parseKeys(text);
  let e2 = null;
  for (const x of entries) if (x.code.toLowerCase() === st.authed.code.toLowerCase()) { e2 = x; break; }
  if (!e2) return;
  if (e2.days !== st.authed.days) {
    const fresh = { code: st.authed.code, expireAt: Date.now() + e2.days * DAY_MS, days: e2.days };
    await chrome.storage.local.set({ authed: fresh });
    const acts = await chrome.storage.local.get({ activations: {} });
    acts.activations[st.authed.code] = { first: Date.now() };
    await chrome.storage.local.set({ activations: acts.activations });
    const n = $('notice');
    n.textContent = 'Phát hiện gói mới .' + e2.days + ' ngày — bộ đếm đã khởi động lại!';
    n.classList.remove('hidden');
    startCountdown();
  }
}

function startRenewalWatch() {
  if (renewTimer) clearInterval(renewTimer);
  checkRenewal();
  renewTimer = setInterval(checkRenewal, 300000);
}

async function enterMain(message) {
  show('main');
  startCountdown();
  startRenewalWatch();
  const notice = $('notice');
  if (message) {
    notice.textContent = message;
    notice.classList.remove('hidden');
  } else {
    notice.classList.add('hidden');
  }
  refresh();
}

function render(state) {
  state = state || {};
  const keys = state.keys || [];
  $('progress-text').textContent = (state.done || 0) + '/' + (state.total || 0);
  const pct = state.total ? Math.round((state.done || 0) / state.total * 100) : 0;
  $('progress-bar').style.width = pct + '%';
  $('status-line').textContent = state.running
    ? ('Đang xử lý link ' + ((state.done || 0) + 1) + '...')
    : (state.total ? 'Hoàn thành: ' + keys.length + '/' + state.total + ' key' : 'Sẵn sàng');
  $('log').textContent = (state.logs || []).join('\n');
  $('log').scrollTop = 1e9;
  renderHistory(state.savedKeys || []);
  $('btn-start').classList.toggle('hidden', !!state.running);
  $('btn-stop').classList.toggle('hidden', !state.running);
}

function fmtTime(t) {
  if (!t) return 'Không rõ thời gian';
  const d = new Date(t);
  const p = function (x) { return String(x).padStart(2, '0'); };
  return p(d.getDate()) + '/' + p(d.getMonth() + 1) + '/' + d.getFullYear() + ' ' + p(d.getHours()) + ':' + p(d.getMinutes());
}

function renderHistory(list) {
  const ul = $('history-list');
  ul.textContent = '';
  const arr = (list || []).slice().sort(function (a, b) { return (b.t || 0) - (a.t || 0); });
  if (!arr.length) {
    const li = document.createElement('li');
    li.className = 'empty';
    li.textContent = 'Chưa lấy key nào.';
    ul.appendChild(li);
    return;
  }
  for (const it of arr) {
    const li = document.createElement('li');
    li.className = 'h-item';
    const top = document.createElement('div');
    top.className = 'h-top';
    const span = document.createElement('span');
    span.className = 'k';
    span.textContent = it.k || it;
    span.title = it.k || it;
    const b = document.createElement('button');
    b.className = 'mini';
    b.textContent = 'Copy';
    b.addEventListener('click', function () {
      navigator.clipboard.writeText(it.k || it);
      b.textContent = 'OK';
      setTimeout(function () { b.textContent = 'Copy'; }, 900);
    });
    top.appendChild(span);
    top.appendChild(b);
    const time = document.createElement('div');
    time.className = 'h-time';
    time.textContent = fmtTime(it.t);
    li.appendChild(top);
    li.appendChild(time);
    ul.appendChild(li);
  }
}

async function refresh() {
  const r = await send({ type: 'GET_STATE' });
  if (r.state) render(r.state);
}

document.addEventListener('DOMContentLoaded', function () {
  boot();

  $('btn-login').addEventListener('click', async function () {
    const code = $('code').value.trim();
    if (!code) { $('login-error').textContent = 'Hãy nhập mã xác minh!'; return; }
    $('btn-login').disabled = true;
    $('login-error').textContent = '';
    $('login-msg').textContent = 'Đang kiểm tra...';
    const r = await login(code);
    $('btn-login').disabled = false;
    $('login-msg').textContent = '';
    if (!r.ok) {
      $('login-error').textContent = r.error || 'Đăng nhập thất bại!';
      const card = $('view-login');
      card.classList.remove('shake');
      void card.offsetWidth;
      card.classList.add('shake');
      return;
    }
    $('code').value = '';
    enterMain(r.message);
  });

  $('code').addEventListener('keydown', function (e) { if (e.key === 'Enter') $('btn-login').click(); });

  $('btn-logout').addEventListener('click', async function () {
    stopTimers();
    await chrome.storage.local.remove('authed');
    show('login');
  });

  $('btn-start').addEventListener('click', async function () {
    $('status-line').textContent = 'Đang khởi động...';
    const r = await send({ type: 'START', count: 1 });
    if (!r.ok) $('status-line').textContent = r.error || 'Lỗi!';
    refresh();
  });

  $('btn-stop').addEventListener('click', async function () {
    await send({ type: 'STOP' });
    refresh();
  });

  $('btn-copy-all').addEventListener('click', async function () {
    const r = await send({ type: 'GET_STATE' });
    const list = (r.state && r.state.savedKeys) || [];
    if (!list.length) return;
    navigator.clipboard.writeText(list.map(function (x) { return x.k || x; }).join('\n'));
    this.textContent = 'Đã copy!';
    setTimeout(function () { $('btn-copy-all').textContent = 'Copy tất cả'; }, 1200);
  });

  $('btn-clear-keys').addEventListener('click', async function () {
    await send({ type: 'CLEAR_KEYS' });
    renderHistory([]);
    refresh();
  });

  chrome.runtime.onMessage.addListener(function (msg) {
    if (msg.type === 'STATE') render(msg.state);
  });
});
